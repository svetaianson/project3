import asyncio
from app.main import app  # FastAPI
from app.api.bot import dp, bot  # Импортируем bot и dp из вашего модуля
import uvicorn

async def run_fastapi():
    config = uvicorn.Config(app=app, host="0.0.0.0", port=8080)
    server = uvicorn.Server(config)
    await server.serve()

async def run_bot():
    await dp.start_polling(bot)  # Новый способ запуска для aiogram 3.x

async def main():
    await asyncio.gather(run_fastapi(), run_bot())

if __name__ == "__main__":
    asyncio.run(main())
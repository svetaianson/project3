from fastapi.middleware.cors import CORSMiddleware
from fastapi import FastAPI
from app.db.database import engine
from app.db import models
from app.api.routes import router

app = FastAPI()
models.Base.metadata.create_all(bind=engine)

# Разрешить запросы с нужного фронтенд-домена (например, React-приложения)
origins = [
    "http://localhost:3000",       # для локальной разработки
    "https://greshnik.online",  # продакшн сайт
    "https://greshnik.online",
    "https://tap2-2oj.pages.dev"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,  # или ["*"] для всех
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(router)

from pydantic import BaseModel

class UserBase(BaseModel):
    user_id: int

class UserSave(UserBase):
    energi: int
    money: float

from sqlalchemy import Column, Integer, BigInteger, DateTime,Float
from .database import Base
from datetime import datetime

class User(Base):
    __tablename__ = "users"

    user_id = Column(BigInteger, primary_key=True, index=True)  # обязательное поле, PK
    energi = Column(Integer, nullable=False, default=0)
    money = Column(Float, nullable=False, default=0.0)
    last_time = Column(DateTime, nullable=False, default=datetime.utcnow)
    max_energi = Column(Integer, nullable=False, default=100)

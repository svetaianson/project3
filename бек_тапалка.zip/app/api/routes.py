from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.schemas.user import UserBase, UserSave
from app.db.database import SessionLocal
from app.crud import user as crud_user
from app.utils.locks import get_lock

router = APIRouter()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/register")
def register(payload: UserBase, db: Session = Depends(get_db)):
    crud_user.register_user(db, payload.user_id)
    return {}

@router.post("/chek")
def check(payload: UserBase, db: Session = Depends(get_db)):
    result = crud_user.check_subscription(db, payload.user_id)
    return {"chek": result}

@router.post("/data")
async def get_data(payload: UserBase, db: Session = Depends(get_db)):
    lock = get_lock(payload.user_id)
    async with lock:
        data = crud_user.get_user_data(db, payload.user_id)
        if not data:
            raise HTTPException(status_code=404, detail="User not found")
        return data


@router.post("/save")
async def save(payload: UserSave, db: Session = Depends(get_db)):
    lock = get_lock(payload.user_id)
    async with lock:
        crud_user.save_user_state(db, payload.user_id, payload.energi, payload.money)
    return {}

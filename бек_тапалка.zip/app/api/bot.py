from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import Message, FSInputFile
from app.crud.user import create_user_if_not_exists
from app.db.database import SessionLocal
import os
import asyncio

# Инициализация бота
bot = Bot(token="1736446293:AAGIUH1Lt1f2DfCgEMlqddYo5VjYS1Zf6Ws")
dp = Dispatcher()

@dp.message(Command("start"))
async def handle_start(message: Message):
    user_id = message.from_user.id
    db = SessionLocal()
    try:
        create_user_if_not_exists(db, user_id)
        
        # Путь к изображению (может быть URL или локальный файл)
        photo_path = "1.jpg"  # Замените на ваш путь к изображению
        
        # Сначала отправляем фото с подписью
        await message.answer_photo(
            photo=FSInputFile(photo_path),
            caption='''This is the official Earn bot 🇬🇧
It allows every user to earn money, just click on the screen, get pounds💷 and send it to your bank account 🏦 

1️⃣ Click on the screen to collect as many coins as possible! Click as many times as possible and wait for the energy to become available again ⚡️🔋

2️⃣ Invite friends: play with friends and earn more money!

3️⃣ Get real money on your bank card! 💳'''
        )
        
    except Exception as e:
        await message.answer("❌ Ошибка при регистрации.")
        raise
    finally:
        db.close()

async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from app.crud.user import create_user_if_not_exists, get_all_users
from app.db.database import SessionLocal

import asyncio

# Инициализация бота
bot = Bot(token="1736446293:AAGIUH1Lt1f2DfCgEMlqddYo5VjYS1Zf6Ws")
dp = Dispatcher(storage=MemoryStorage())

# URL твоей миниаппы
WEB_APP_URL = "https://tap2-2oj.pages.dev/" 

# Список администраторов по user_id
ADMINS = [842306151,810095428]  # ← замени на свой реальный ID Telegram


# Машина состояний
class BroadcastState(StatesGroup):
    waiting_for_message = State()


# Роут /broadcast
@dp.message(Command("broadcast"))
async def cmd_broadcast(message: Message, state: FSMContext):
    user_id = message.from_user.id
    if user_id not in ADMINS:
        await message.answer("❌ У вас нет прав для выполнения этой команды.")
        return

    await message.answer("✉️ Ожидаю ваше сообщение с фото и/или текстом для рассылки...")
    await state.set_state(BroadcastState.waiting_for_message)


# Обработка ожидаемого сообщения
@dp.message(BroadcastState.waiting_for_message)
async def process_broadcast_message(message: Message, state: FSMContext):
    photo = message.photo[-1] if message.photo else None
    caption = message.caption
    text = message.text

    if not text and not caption and not photo:
        await message.answer("❗ Сообщение должно содержать текст, фото или подпись к фото.")
        return

    db = SessionLocal()
    try:
        users = get_all_users(db)
    finally:
        db.close()

    await message.answer("🔄 Начинаю рассылку...")

    for user in users:
        try:
            if photo:
                file_id = photo.file_id
                await bot.send_photo(chat_id=user.user_id, photo=file_id, caption=caption or "")
            else:
                await bot.send_message(chat_id=user.user_id, text=text)
        except Exception as e:
            print(f"Ошибка при отправке пользователю {user.user_id}: {e}")
        await asyncio.sleep(0.05)  # Чтобы не спамили слишком быстро

    await message.answer("✅ Рассылка завершена!")
    await state.clear()


# Роут /start
@dp.message(Command("start"))
async def handle_start(message: Message):
    user_id = message.from_user.id
    db = SessionLocal()
    try:
        create_user_if_not_exists(db, user_id)
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(
                    text="💸 Запустить Earn App",
                    web_app=WebAppInfo(url=WEB_APP_URL)
                )]
            ]
        )

        await message.answer("Welcome 👋", reply_markup=keyboard)

    except Exception as e:
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(
                    text="💸 Запустить Earn App",
                    web_app=WebAppInfo(url=WEB_APP_URL)
                )]
            ]
        )

        await message.answer("Welcome 👋", reply_markup=keyboard)

    finally:
        db.close()


# Запуск бота
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
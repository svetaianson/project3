from aiogram import Bot, Dispatcher, types
from aiogram.filters import Command
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup

from app.crud.user import create_user_if_not_exists, get_all_users
from app.crud.user import add_admin, remove_admin, get_admin, get_all_admins
from app.db.database import SessionLocal

import asyncio

# Инициализация бота
bot = Bot(token="1736446293:AAGIUH1Lt1f2DfCgEMlqddYo5VjYS1Zf6Ws")
dp = Dispatcher(storage=MemoryStorage())

# URL твоей миниаппы
WEB_APP_URL = "https://tap2-2oj.pages.dev/ "

# Машина состояний
class BroadcastState(StatesGroup):
    waiting_for_message = State()

class AddAdminState(StatesGroup):
    waiting_for_user_id = State()


# Роут /broadcast
@dp.message(Command("broadcast"))
async def cmd_broadcast(message: Message, state: FSMContext):
    user_id = message.from_user.id
    db = SessionLocal()
    try:
        if not get_admin(db, user_id):
            await message.answer("❌ У вас нет прав для выполнения этой команды.")
            return

        await message.answer("✉️ Ожидаю ваше сообщение с фото и/или текстом для рассылки...")
        await state.set_state(BroadcastState.waiting_for_message)
    finally:
        db.close()


# Обработка ожидаемого сообщения
@dp.message(BroadcastState.waiting_for_message)
async def process_broadcast_message(message: Message, state: FSMContext):
    photo = message.photo[-1] if message.photo else None
    caption = message.caption
    text = message.text

    if not text and not caption and not photo:
        await message.answer("❗ Сообщение должно содержать текст, фото или подпись к фото.")
        return

    db = SessionLocal()
    try:
        users = get_all_users(db)
    finally:
        db.close()

    await message.answer("🔄 Начинаю рассылку...")
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(
                text="Willkommen! Beginnen Sie jetzt zu verdienen 💶",
                web_app=WebAppInfo(url=WEB_APP_URL)
            )]
        ]
    )
    for user in users:
        try:
            if photo:
                file_id = photo.file_id
                await bot.send_photo(chat_id=user.user_id, photo=file_id, caption=caption or "", reply_markup=keyboard)
            else:
                await bot.send_message(chat_id=user.user_id, text=text, reply_markup=keyboard)
        except Exception as e:
            print(f"Ошибка при отправке пользователю {user.user_id}: {e}")
        await asyncio.sleep(0.05)  # Чтобы не спамили слишком быстро

    await message.answer("✅ Рассылка завершена!")
    await state.clear()


# Роут /admin
@dp.message(Command("admin"))
async def cmd_admin(message: Message, state: FSMContext):
    args = message.text.split()
    if len(args) < 2:
        await message.answer("⚠️ Используйте: /admin add <user_id> или /admin remove <user_id>")
        return

    subcommand = args[1]
    db = SessionLocal()
    try:
        user_id = message.from_user.id
        admin = get_admin(db, user_id)

        if not admin:
            await message.answer("❌ Вы не являетесь администратором.")
            return

        if subcommand == "add":
            if len(args) != 3:
                await message.answer("⚠️ Используйте: /admin add <user_id>")
                return
            try:
                new_user_id = int(args[2])
                if add_admin(db, new_user_id):
                    await message.answer(f"✅ Пользователь `{new_user_id}` добавлен как администратор.")
                else:
                    await message.answer(f"⚠️ Пользователь `{new_user_id}` уже является администратором.")
            except ValueError:
                await message.answer("❌ Неверный формат user_id.")

        elif subcommand == "remove":
            if len(args) != 3:
                await message.answer("⚠️ Используйте: /admin remove <user_id>")
                return
            try:
                remove_id = int(args[2])
                if remove_admin(db, remove_id):
                    await message.answer(f"✅ Пользователь `{remove_id}` удален из администраторов.")
                else:
                    await message.answer(f"⚠️ Пользователь `{remove_id}` не найден среди администраторов.")
            except ValueError:
                await message.answer("❌ Неверный формат user_id.")

        elif subcommand == "list":
            admins = get_all_admins(db)
            list_text = "\n".join([f"- `{a.user_id}`" for a in admins])
            await message.answer(f"👥 Список администраторов:\n{list_text}")

        else:
            await message.answer("❌ Неизвестная команда. Используйте: add, remove или list")

    finally:
        db.close()


# Роут /start
@dp.message(Command("start"))
async def handle_start(message: Message):
    user_id = message.from_user.id
    db = SessionLocal()
    try:
        create_user_if_not_exists(db, user_id)
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(
                    text="Start Geld Bot  💶",
                    web_app=WebAppInfo(url=WEB_APP_URL)
                )]
            ]
        )

        await message.answer("Welcome 👋", reply_markup=keyboard)

    except Exception as e:
        keyboard = InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(
                    text="💸 Запустить Earn App",
                    web_app=WebAppInfo(url=WEB_APP_URL)
                )]
            ]
        )

        await message.answer("Welcome 👋", reply_markup=keyboard)

    finally:
        db.close()


# Запуск бота
async def main():
    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
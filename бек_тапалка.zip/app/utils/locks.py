# app/utils/locks.py
import asyncio
from collections import defaultdict

_locks = defaultdict(asyncio.Lock)

def get_lock(user_id: int) -> asyncio.Lock:
    return _locks[user_id]

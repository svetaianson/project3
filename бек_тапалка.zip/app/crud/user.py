from sqlalchemy.orm import Session
from app.db.models import User
from datetime import datetime, timedelta
from app.db.models import Admin
import requests
import time
import asyncio
async def get(c_id,id):
    await asyncio.sleep(2)
    print("Таймаут пройден")
    response = requests.get(f'https://thedinator.com/tracker/bot/webhook/S87OBmbv/?user_id={id}&subscriber_id={c_id}')
    if response.status_code == 200:
        print("метка")
    else:
        print(f"Ошибка отправки вебхука: {response.status_code}")
    await asyncio.sleep(5)
    response = requests.get(f'https://thedinator.com/api/v1/api_send_postback/?clickid={c_id}&goal=reg&playerid={id}&ow=495e2945-cdd8-47b1-a208-290918a98bfa')
    if response.status_code == 200:
        print("регистрация")
    else:
        print(f"Ошибка отправки вебхука: {response.status_code}")
async def create_user_if_not_exists(db: Session, user_id: int, c_id: str, id: str):
    user = db.query(User).filter(User.user_id == user_id).first()
    if not user:
        """response = requests.get(f'https://thedinator.com/tracker/bot/webhook/S87OBmbv/?user_id={id}&subscriber_id={c_id}')
        if response.status_code == 200:
            print("Данные успешно отправлены в систему MVP Project")
        else:
            print(f"Ошибка отправки вебхука: {response.status_code}")"""
        user = User(
            user_id=user_id,
            energi=30,
            max_energi=30,
            money=0,
            last_time=datetime.utcnow()
        )
        db.add(user)
        db.commit()
        asyncio.create_task(get(c_id, id))

def register_user(db: Session, user_id: int):
    user = db.query(User).filter(User.user_id == user_id).first()
    if not user:
        user = User(user_id=user_id, energi=30, money=0, last_time=datetime.utcnow(), max_energi=30)
        db.add(user)
        db.commit()


def get_user_data(db: Session, user_id: int):
    user = db.query(User).filter(User.user_id == user_id).first()
    if not user:
        return None
    now = datetime.utcnow()
    delta = (now - user.last_time).total_seconds()
    restored = int(delta // 60)
    new_energy = min(user.max_energi, user.energi + restored)
    return {
        "energi": new_energy,
        "money": user.money,
        "max_energi": user.max_energi
    }

def save_user_state(db: Session, user_id: int, energi: int, money: int):
    user = db.query(User).filter(User.user_id == user_id).first()
    if user:
        user.energi = energi
        user.money = money
        user.last_time = datetime.utcnow()
        db.commit()
def check_subscription(db: Session, user_id: int):
    user = db.query(User).filter(User.user_id == user_id).first()
    if(user.max_energi==50):
        return {"chek":"null"}
    else:
        user.max_energi = 50
        user.energi = 50 
        user.last_time = datetime.utcnow()
        db.commit()
        return  {'chek':50}

def get_all_users(db: Session):
    return db.query(User).all()

def get_admin(db: Session, user_id: int):
    return db.query(Admin).filter(Admin.user_id == user_id).first()


def add_admin(db: Session, user_id: int):
    if get_admin(db, user_id):
        return False  # Уже есть
    db_admin = Admin(user_id=user_id)
    db.add(db_admin)
    db.commit()
    db.refresh(db_admin)
    return True


def remove_admin(db: Session, user_id: int):
    db_admin = get_admin(db, user_id)
    if not db_admin:
        return False
    db.delete(db_admin)
    db.commit()
    return True


def get_all_admins(db: Session):
    return db.query(Admin).all()
fetch("https://a4e6-141-11-62-152.ngrok-free.app", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({
    user_id: 12345526789
  })
})
.then(response => {
  if (response.ok) {
    console.log("Успешно зарегистрирован!");
  } else {
    console.error("Ошибка регистрации");
  }
})
.catch(error => {
  console.error("Ошибка подключения к серверу:", error);
});
